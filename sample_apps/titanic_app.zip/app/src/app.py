import json
from time import time
from random import random
from flask import Flask, render_template, make_response,request
from getdata import getheat
import requests

app = Flask(__name__)

models = json.loads(open('app_contract.json').read())['models']
survivor_count = 0

@app.route('/')
def hello_world():
    return render_template('index.html', data='test')

@app.route('/live-data')
def live_data():
    global survivor_count
    row = getheat()
    data = {'arr': row}
    r = requests.post(models["model1"], json=data)
    if r.text == 'Survived':
        survivor_count += 1
    else:
        survivor_count -= 1
    # Create a PHP array and echo it as JSON
    data = [time() * 1000, survivor_count]
    print(data)
    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)

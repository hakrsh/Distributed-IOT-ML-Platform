def postprocess(pred):
    if pred[0] == 0:
        return 'Safe'
    else:
        return 'Critical'

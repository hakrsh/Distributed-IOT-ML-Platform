# Patient Condition Predictor
#### Input
Patient Vitals
``` json
{"spo2": spo2, "temperature": temperature, "pulse": pulse}
```

#### Output
```
Critical or Safe
```

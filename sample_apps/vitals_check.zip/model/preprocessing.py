import numpy as np

def preprocess(data):
    spo2 = int(data['spo2'])
    temperature = int(data['temperature'])
    pulse = int(data['pulse'])
    return [[spo2, temperature, pulse]]

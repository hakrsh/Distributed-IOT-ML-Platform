import json
import logging
import random
from time import time
from urllib import response
from flask import Flask, Response, flash, make_response, render_template, request, url_for, redirect, session
import pickle
import sqlite3
import logging
from PIL import Image
import io
import cv2
import numpy as np
import requests
logging.basicConfig(level=logging.INFO)

logging.info('importing sensor,controller,model interface...')
from controller import send_sms,turn_on_light
from getdata import getcam1,getcam2
models = json.loads(open('models.json').read())
logging.info('imported sensor,controller,model interface sucessfully...')

app = Flask(__name__)
app.secret_key = "testing"
logging.info('Creating local database...')
db = sqlite3.connect('classroom.db', check_same_thread=False)
db.execute(
    "CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT, email TEXT)")
db.execute("CREATE TABLE IF NOT EXISTS prof (name TEXT, phone_number TEXT)")
db.execute("CREATE TABLE IF NOT EXISTS students (name TEXT)")

@app.route('/health', methods=['GET'])
def health():
    return 'OK', 200
@app.route("/", methods=['post', 'get'])
def index():
    if request.method == 'GET':
        return render_template('index.html')
    else:
        username = request.form['username']
        password = request.form['password']
        repeat_password = request.form['repeat_password']
        email = request.form['email']
        if username == '' or password == '' or email == '':
            flash('Please fill in all the fields', 'error')
            return render_template('index.html', error='Please fill all the fields')
        elif db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone() is not None:
            flash('Username already exists', 'error')
            return render_template('index.html')
        elif password != repeat_password:
            flash('Passwords do not match', 'error')
            return render_template('index.html')
        else:
            db.execute("INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
                       (username, password, email))
            db.commit()
            flash('You have successfully registered', 'success')
            return redirect(url_for('login'))


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "GET":
        return render_template('login.html')
    else:
        email = request.form['email']
        password = request.form['password']
        if email == '' or password == '':
            flash('Please fill in all the fields', 'error')
            return render_template('login.html', error='Please fill all the fields')
        else:
            user_data = db.execute(
                "SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if user_data is None:
                flash('email does not exist', 'error')
                return render_template('login.html')
            else:
                if password == user_data[2]:
                    session['email'] = user_data[1]
                    return redirect(url_for('logged_in'))
                else:
                    flash('Incorrect password', 'error')
                    return render_template('login.html')


@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email = session["email"]
        return render_template('logged_in.html', email=email)
    else:
        return redirect(url_for("login"))


@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "email" in session:
        session.pop("email", None)
        return render_template("signout.html")
    else:
        return render_template('index.html')


@app.route("/add_prof", methods=["POST", "GET"])
def add_prof():
    if "email" in session:
        if request.method == "GET":
            return render_template('add_prof.html')
        if request.method == "POST":
            name = request.form.get("fullname")
            phone_number = request.form.get("phonenumber")
            if name == '' or phone_number == '':
                flash('Please fill in all the fields', 'error')
                return render_template('add_students.html', error='Please fill all the fields')
            elif db.execute("SELECT * FROM prof WHERE name = ?", (name,)).fetchone() is not None:
                flash('Doctor already exists', 'error')
                return render_template('add_students.html')
            else:
                db.execute(
                    "INSERT INTO prof (name, phone_number) VALUES (?, ?)", (name, phone_number))
                db.commit()
                flash('Professor registration successful', 'success')
                return redirect(url_for('add_students'))                
    else:
        flash('Please login to your account', 'error')
        return redirect(url_for("login"))


# @app.route("/delete_patient", methods=["POST", "GET"])
# def delete_patient():
#     if "email" in session:
#         db.execute("DELETE FROM patients")
#         db.commit()
#         flash('Patient deleted successfully', 'success')
#         return redirect(url_for('add_prof'))
#     else:
#         return redirect(url_for("login"))


@app.route("/add_students", methods=["POST", "GET"])
def add_students():
    if "email" in session:
        if request.method == 'GET':
            return render_template('add_students.html')
        else:
            name = request.form.get("fullname")
            if name == '':
                flash('Please fill in all the fields', 'error')
                return render_template('add_students.html', error='Please fill all the fields')
            elif db.execute("SELECT * FROM students WHERE name = ?", (name,)).fetchone() is not None:
                flash('Student already exists', 'error')
                return redirect(url_for('logged_in'))
            else:
                for name in name.split(','):
                    db.execute("INSERT INTO students (name) VALUES (?)", (name,))
                db.commit()
                flash('Student added successfully', 'success')
                return redirect(url_for('logged_in'))
    else:
        return redirect(url_for("login"))


@app.route("/show_attendance", methods=["POST", "GET"])
def show_attendance():
    if "email" in session:
        if request.method == "GET":
            if db.execute("SELECT * FROM students").fetchone() is None:
                flash('No patient found', 'error')
                return render_template('add_prof.html')
            if db.execute("SELECT * FROM prof").fetchone() is None:
                flash('No doctor found', 'error')
                return render_template('add_students.html')
            else:
                students = {}
                for name in db.execute("SELECT name FROM students"):
                    students[name[0]] = 0
                total_students = db.execute("SELECT * FROM students").fetchall().__len__()
                logging.info('Gettting image from camera...')
                image = getcam1()
                logging.info('Image obtained')
                logging.info('Senting image to model to detect faces...')
                resp= requests.post(models["attendance_check"], data=json.dumps({"image":list(image)}))
                logging.info('Prediction from model: ' + resp.text)
                #students_presnts = int(requests.post(models["attendance_check"], data=image).text)
                # students_presnts = random.randint(0, total_students)
                students_presnts = int(resp.text)
                for i in range(students_presnts):
                    while True:
                        random_student = random.choice(list(students.keys()))
                        if students[random_student] == 0:
                            students[random_student] = 1
                            break
                print(students)
                prof = db.execute("SELECT * FROM prof").fetchone()
                phone_number = prof[1]
                message = "Attendance of the day: " + str(students_presnts) + " out of " + str(total_students)
                send_sms(phone_number, message)
                return render_template('attendance.html', total_students=total_students, students_presnts=students_presnts, students=students)

    else:
        return redirect(url_for("login"))

@app.route("/get_attention", methods=["POST", "GET"])
def show_attention():
    if "email" in session:
        if request.method == "GET":
            if db.execute("SELECT * FROM students").fetchone() is None:
                flash('No students found', 'error')
                return render_template('add_prof.html')
            if db.execute("SELECT * FROM prof").fetchone() is None:
                flash('No prof found', 'error')
                return render_template('add_students.html')
            else:
                students = {}
                for name in db.execute("SELECT name FROM students"):
                    students[name[0]] = 0
                total_students = db.execute("SELECT * FROM students").fetchall().__len__()
                logging.info('Gettting image from camera...')
                image = getcam1()
                logging.info('Image obtained')
                logging.info('Senting image to model: attentiveness_checker...')
                resp= requests.post(models["attentiveness_checker"], data=json.dumps({"image":list(image)}))
                logging.info('Prediction from model: ' + resp.text)
                #students_presnts = int(requests.post(models["attendance_check"], data=image).text)
                # students_presnts = random.randint(0, total_students)
                attentiveness = float(resp.text)
                if attentiveness < 0.3:
                    turn_on_light(0)
                    return 'Attentiveness is low'
                elif attentiveness < 0.6:
                    turn_on_light(1)
                    return 'Attentiveness is medium'
                else :
                    turn_on_light(2)
                return 'Attentiveness is high'
    else:
        return redirect(url_for("login"))

# @app.route("/get_motion", methods=["POST", "GET"])
# def show_motion():
#     if "email" in session:
#         if request.method == "GET":
#             if db.execute("SELECT * FROM students").fetchone() is None:
#                 flash('No students found', 'error')
#                 return render_template('add_prof.html')
#             if db.execute("SELECT * FROM prof").fetchone() is None:
#                 flash('No prof found', 'error')
#                 return render_template('add_students.html')
#             else:
#                 images = []
#                 logging.info('Gettting image from camera...')
#                 for i in range(10):
#                     images.append(list(getcam1()))
#                 logging.info('10 Image obtained')
#                 logging.info('Senting image to model: motion_checker...')
#                 resp= requests.post(models["motion_checker"], data=json.dumps({"images":list(images)}))
#                 logging.info('Prediction from model: ' + resp.text)
#                 motion = float(resp.text)
#                 if motion == 'no':
#                     turn_on_light(0)
#                     return 'No motion detected'
#                 else :
#                     turn_on_light(2)
#                 return 'Motion detected'
#     else:
#         return redirect(url_for("login"))

def motion_detection():
    frame_count = 0
    previous_frame = None

    while True:
        frame_count += 1
        
        # response = requests.get('http://127.0.0.1:8085/video_frame')
        response = getcam2()
        img_brg = Image.open(io.BytesIO(response))
        img_rgb = cv2.cvtColor(src=np.array(img_brg), code=cv2.COLOR_BGR2RGB)
        
#         if (frame_count % 2) == 0:
#             prepared_frame = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
#             prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(5,5), sigmaX=0)
        
        prepared_frame = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
        prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(5,5), sigmaX=0)
        if previous_frame is None:
            previous_frame = prepared_frame
            continue

        # calculate difference and update previous frame
        diff_frame = cv2.absdiff(src1=previous_frame, src2=prepared_frame)
        previous_frame = prepared_frame

        # 4. Dilute the image a bit to make differences more seeable; more suitable for contour detection
        kernel = np.ones((5, 5))
        diff_frame = cv2.dilate(diff_frame, kernel, 1)

        # 5. Only take different areas that are different enough (>20 / 255)
        thresh_frame = cv2.threshold(src=diff_frame, thresh=20, maxval=255, type=cv2.THRESH_BINARY)[1]

        contours, _ = cv2.findContours(image=thresh_frame, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(image=img_rgb, contours=contours, contourIdx=-1, color=(0, 255, 0), thickness=2, lineType=cv2.LINE_AA)
        ret, buffer = cv2.imencode('.jpg', img_rgb)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

        # if (cv2.waitKey(30) == 27):
        #     break

@app.route('/video_feed')
def video_feed():
    return Response(motion_detection(), mimetype='multipart/x-mixed-replace; boundary=frame')


def gen_frames():  
    while True:
        data = getcam1()
        frame = data
        yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/live_feed')
def live_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(port=80,host='0.0.0.0')

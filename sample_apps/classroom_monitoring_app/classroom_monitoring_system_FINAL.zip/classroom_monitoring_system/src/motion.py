import requests
import time
from PIL import Image
import io
import cv2
import numpy as np
from flask import Flask, render_template, Response

app = Flask(__name__)

def motion_detection():
    frame_count = 0
    previous_frame = None

    while True:
        frame_count += 1
        
        response = requests.get('http://127.0.0.1:8085/video_frame')
        img_brg = Image.open(io.BytesIO(response.content))
        img_rgb = cv2.cvtColor(src=np.array(img_brg), code=cv2.COLOR_BGR2RGB)
        
#         if (frame_count % 2) == 0:
#             prepared_frame = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
#             prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(5,5), sigmaX=0)
        
        prepared_frame = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
        prepared_frame = cv2.GaussianBlur(src=prepared_frame, ksize=(5,5), sigmaX=0)
        if previous_frame is None:
            previous_frame = prepared_frame
            continue

        # calculate difference and update previous frame
        diff_frame = cv2.absdiff(src1=previous_frame, src2=prepared_frame)
        previous_frame = prepared_frame

        # 4. Dilute the image a bit to make differences more seeable; more suitable for contour detection
        kernel = np.ones((5, 5))
        diff_frame = cv2.dilate(diff_frame, kernel, 1)

        # 5. Only take different areas that are different enough (>20 / 255)
        thresh_frame = cv2.threshold(src=diff_frame, thresh=20, maxval=255, type=cv2.THRESH_BINARY)[1]

        contours, _ = cv2.findContours(image=thresh_frame, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(image=img_rgb, contours=contours, contourIdx=-1, color=(0, 255, 0), thickness=2, lineType=cv2.LINE_AA)
        ret, buffer = cv2.imencode('.jpg', img_rgb)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

        # if (cv2.waitKey(30) == 27):
        #     break

@app.route('/video_feed')
def video_feed():
    return Response(motion_detection(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(port=8086, host='0.0.0.0')


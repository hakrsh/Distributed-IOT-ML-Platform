import pickle
import importlib.resources as pkg_resources
import logging
import json
logging.basicConfig(level=logging.INFO)
def predict_condition(data):
    data = json.loads(data)
    logging.info('Inside predict_condition')
    logging.info('Unpacking data....')
    spo2 = int(data['spo2'])
    temperature = int(data['temperature'])
    pulse = int(data['pulse'])
    logging.info('spo2: %s, temperature: %s, pulse: %s', spo2, temperature, pulse)
    logging.info('loading model')
    model = pickle.load(pkg_resources.open_binary('patient_monitoring.vitals_checker', 'vitals_checker.pkl'))
    logging.info('Predicting')
    pred = model.predict([[spo2, temperature, pulse]])
    res = ''
    if pred[0] == 0:
        res = 'Safe'
    else:
        res = 'Critical'
    logging.info('Prediction: ' + res)
    return res

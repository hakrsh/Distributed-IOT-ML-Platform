import json
import random
from time import time
from flask import Flask, flash, make_response, render_template, request, url_for, redirect, session
import pickle
import sqlite3

import requests
from sent_msg import send_sms
from getdata import getspo2, getpulserate, gettemperature
models = json.loads(open('app_contract.json').read())['models']

app = Flask(__name__)
app.secret_key = "testing"

db = sqlite3.connect('hospital.db', check_same_thread=False)
db.execute(
    "CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT, email TEXT)")
db.execute("CREATE TABLE IF NOT EXISTS patients (name TEXT, disease TEXT, age INTEGER, height INTEGER, weight INTEGER)")
db.execute("CREATE TABLE IF NOT EXISTS doctors (name TEXT, phone_number TEXT)")

@app.route('/health', methods=['GET'])
def health():
    return 'OK', 200
@app.route("/", methods=['post', 'get'])
def index():
    if request.method == 'GET':
        return render_template('index.html')
    else:
        username = request.form['username']
        password = request.form['password']
        repeat_password = request.form['repeat_password']
        email = request.form['email']
        if username == '' or password == '' or email == '':
            flash('Please fill in all the fields', 'error')
            return render_template('index.html', error='Please fill all the fields')
        elif db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone() is not None:
            flash('Username already exists', 'error')
            return render_template('index.html')
        elif password != repeat_password:
            flash('Passwords do not match', 'error')
            return render_template('index.html')
        else:
            db.execute("INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
                       (username, password, email))
            db.commit()
            flash('You have successfully registered', 'success')
            return redirect(url_for('login'))


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "GET":
        return render_template('login.html')
    else:
        email = request.form['email']
        password = request.form['password']
        if email == '' or password == '':
            flash('Please fill in all the fields', 'error')
            return render_template('login.html', error='Please fill all the fields')
        else:
            user_data = db.execute(
                "SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if user_data is None:
                flash('email does not exist', 'error')
                return render_template('login.html')
            else:
                if password == user_data[2]:
                    session['email'] = user_data[1]
                    return redirect(url_for('logged_in'))
                else:
                    flash('Incorrect password', 'error')
                    return render_template('login.html')


@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email = session["email"]
        return render_template('logged_in.html', email=email)
    else:
        return redirect(url_for("login"))


@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "email" in session:
        session.pop("email", None)
        return render_template("signout.html")
    else:
        return render_template('index.html')


@app.route("/add_patient", methods=["POST", "GET"])
def add_patient():
    if "email" in session:
        if request.method == "GET":
            return render_template('add_patient.html')
        if request.method == "POST":
            name = request.form.get("name")
            disease = request.form.get("disease")
            age = request.form.get("age")
            height = request.form.get("height")
            weight = request.form.get("weight")
            if name == '' or disease == '' or age == '' or height == '' or weight == '':
                flash('Please fill in all the fields', 'error')
                return render_template('add_patient.html', error='Please fill all the fields')
            elif db.execute("SELECT * FROM patients").fetchone() is not None:
                flash('Only one patient is allowed', 'error')
                return render_template('show_patient.html')
            else:
                db.execute("INSERT INTO patients (name, disease, age, height, weight) VALUES (?, ?, ?, ?, ?)",
                           (name, disease, age, height, weight))
                db.commit()
                flash('Patient added successfully', 'success')
                return redirect(url_for('add_doctor'))
    else:
        flash('Please login to your account', 'error')
        return redirect(url_for("login"))


@app.route("/delete_patient", methods=["POST", "GET"])
def delete_patient():
    if "email" in session:
        db.execute("DELETE FROM patients")
        db.commit()
        flash('Patient deleted successfully', 'success')
        return redirect(url_for('add_patient'))
    else:
        return redirect(url_for("login"))


@app.route("/add_doctor", methods=["POST", "GET"])
def add_doctor():
    if "email" in session:
        if request.method == 'GET':
            return render_template('add_doctor.html')
        else:
            name = request.form.get("fullname")
            phone_number = request.form.get("phonenumber")
            if name == '' or phone_number == '':
                flash('Please fill in all the fields', 'error')
                return render_template('add_doctor.html', error='Please fill all the fields')
            elif db.execute("SELECT * FROM doctors WHERE name = ?", (name,)).fetchone() is not None:
                flash('Doctor already exists', 'error')
                return render_template('add_doctor.html')
            else:
                db.execute(
                    "INSERT INTO doctors (name, phone_number) VALUES (?, ?)", (name, phone_number))
                db.commit()
                flash('Doctor added successfully', 'success')
                return redirect(url_for('add_doctor'))
    else:
        return redirect(url_for("login"))


@app.route("/show_patient", methods=["POST", "GET"])
def show_patient():
    if "email" in session:
        if request.method == "GET":
            if db.execute("SELECT * FROM patients").fetchone() is None:
                flash('No patient found', 'error')
                return render_template('add_patient.html')
            if db.execute("SELECT * FROM doctors").fetchone() is None:
                flash('No doctor found', 'error')
                return render_template('add_doctor.html')
            else:
                return render_template('show_patient.html')
    else:
        return redirect(url_for("login"))


@app.route("/live-data-new", methods=["POST", "GET"])
def live_data_new():
    data4 = ""
    # API Calls here
    # spo2 = random.randint(85, 95)
    # temperature = random.randint(97, 99)
    # pulse = random.randint(60, 70)
    spo2 = getspo2()
    temperature = gettemperature()
    pulse = getpulserate()

    # row = [spo2, temperature, pulse]

    # open pkl file
    # with open('model.pkl', 'rb') as f:
    #     model = pickle.load(f)

    # result = model.predict([row])[0]
    result = requests.post(models["vitals_check"], json={"spo2": spo2, "temperature": temperature, "pulse": pulse}).text

    if(result == 'Critical'):
        data4 = "Critical"
        doctors = db.execute("SELECT * FROM doctors").fetchall()
        numbers = ''
        for doctor in doctors:
            numbers += doctor[1] + ','
        numbers = numbers[:-1]
        patient_data = db.execute("SELECT * FROM patients").fetchone()
        message = "Patient " + patient_data[0] + " is in critical condition."
        send_sms(numbers, message)
    else:
        data4 = "Safe"

    # generate random values using random function

    data = {}
    data['spo2'] = spo2
    data['temperature'] = temperature
    data['pulse'] = pulse
    data['condition'] = data4
    data['timestamp'] = time() * 1000
    patient_data = db.execute("SELECT * FROM patients").fetchone()
    print(patient_data)
    patient_name = patient_data[0]
    patient_disease = patient_data[1]
    doctors = db.execute("SELECT * FROM doctors").fetchall()

    patient_data = ""
    patient_data += patient_name + " : "
    patient_data += patient_disease

    data['patient_data'] = patient_data

    doctor_data = ""
    for i in range(len(doctors)):
        doctor_name = doctors[i][0]
        doctor_phone_number = doctors[i][1]
        doctor_data += doctor_name + " : "
        doctor_data += doctor_phone_number
        doctor_data += " "
    data['doctor_data'] = doctor_data

    print(data)
    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response

@app.route('/predict',methods=['GET','POST'])
def predict():
    if session.get('email') is None:
        flash('Please login to your account', 'error')
        return redirect(url_for('login'))
    elif db.execute("SELECT * FROM patients").fetchone() is None:
        flash('No patient found', 'error')
        return redirect(url_for('add_patient'))
    if request.method == 'GET':
        return render_template('diabetes.html')
    else:
        patient_data = db.execute("SELECT * FROM patients").fetchone()
        age = patient_data[2]
        height = patient_data[3]
        weight = patient_data[4]
        bmi = weight / (height * height)
        glucose = request.form.get("glucose")
        insuline = request.form.get("insuline")

        # float_features = [float(x) for x in request.form.values()]
        
        # float_features = [glucose, insuline,bmi,age]
    
        # final_features = [np.array(float_features)]
        # prediction = model.predict( sc.transform(final_features) )

        prediction = requests.post(models["diabetes_check"], json={"glucose":glucose,"insuline":insuline,"bmi":bmi,"age":age}).text

        pred = ""
        if prediction == 'true':
            pred = "You have Diabetes, please consult a Doctor."
        elif prediction == 'false':
            pred = "You don't have Diabetes."
        return render_template('diabetes.html', prediction_text='{}'.format(pred))

if __name__ == "__main__":
    app.run(port=80,host='0.0.0.0')

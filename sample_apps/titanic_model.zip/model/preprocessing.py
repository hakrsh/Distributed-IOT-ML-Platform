import numpy as np

def preprocess(data):
    sex = 0
    if data['arr']['Sex'] == 'female':
        sex = 1
    res = [data['arr']['Pclass'], sex,
            data['arr']['Age'], data['arr']['SibSp'], data['arr']['Parch'], data['arr']['Fare']]
    res = np.array(res)
    res = res.reshape(1, -1)
    return res

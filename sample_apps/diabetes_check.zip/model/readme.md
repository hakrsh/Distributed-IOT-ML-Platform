# Titanic Survivor Prediction 
#### Input
Passenger data
``` json
row = {'SL': '323', 'PassengerId': '1215', 'Pclass': '1', 'Name': 'Rowe, Mr. Alfred G', 'Sex': 'male', 'Age': '33', 'SibSp': '0', 'Parch': '0', 'Ticket': '113790', 'Fare': '26.55', 'Cabin': '', 'Embarked': 'S'}
```

#### Output
```
Survived or Not Survived
```

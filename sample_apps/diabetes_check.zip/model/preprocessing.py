import numpy as np
import pandas as pd

def preprocess(data):
    dataset = pd.read_csv('diabetes.csv')
    dataset_X = dataset.iloc[:,[1, 2, 5, 7]].values
    from sklearn.preprocessing import MinMaxScaler
    sc = MinMaxScaler(feature_range = (0,1))
    sc.fit_transform(dataset_X)

    age = float(data['age'])
    bmi = float(data['bmi'])
    glucose = float(data['glucose'])
    insuline = float(data['insuline'])
    float_features = [glucose, insuline,bmi,age]
    final_features = [np.array(float_features)]
    return sc.transform(final_features)

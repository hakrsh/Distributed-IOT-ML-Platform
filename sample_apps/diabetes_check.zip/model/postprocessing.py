def postprocess(pred):
    if pred[0] == 0:
            return 'false'
    else:
        return 'true'
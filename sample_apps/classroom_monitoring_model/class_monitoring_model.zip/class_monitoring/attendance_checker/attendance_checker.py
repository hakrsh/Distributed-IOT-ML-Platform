import dill as pickle
from io import BytesIO
from PIL import Image
import json
import logging
logging.basicConfig(level=logging.INFO)
import importlib.resources as pkg_resources
logging.info('Loading model...')
model = pickle.load(pkg_resources.open_binary('class_monitoring.attendance_checker', 'attendance_checker.pkl'))
logging.info('Model loaded.')
# model = pickle.load(open('face_counter.pkl', 'rb'))
def count_students(data):   
    data = json.loads(data) 
    image = bytes(data["image"])
    logging.info('Counting students...')
    logging.info('Writing image to file...')
    im = Image.open(BytesIO(image))
    filename = 'test.jpg'
    im.save(filename)
    logging.info('Image written to file.')
    logging.info('Predicting...')
    pred = model(filename)
    logging.info('Prediction: ' + str(pred))
    return str(pred)
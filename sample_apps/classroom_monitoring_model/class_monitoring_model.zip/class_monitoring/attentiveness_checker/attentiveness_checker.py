from io import BytesIO
from PIL import Image
import json
import logging
logging.basicConfig(level=logging.INFO)

from matplotlib import pyplot
from mtcnn.mtcnn import MTCNN
import cv2
import os
from fer import FER

errors = []

detector = MTCNN()
emo_detector = FER(mtcnn=True)

def detect_emo(filename):
    positive_emotions = ["happy", "surprise", "neutral"]
    try:
        mode = 2
        current_image = pyplot.imread(filename)
        img = current_image
        data = detector.detect_faces(current_image)
        length = len(data)
        dest_path = "./faces/biggest.jpg"
        dest_dir = "./faces"
        
        attentive_count = 0
        if data ==[]:
            uncropped_file_list.append(f_path)
        else:
            if mode==1:
                for i, faces in enumerate(data): # iterate through all the faces found
                    box=faces['box']  # get the box for each face                
                    biggest=0                    
                    area = box[3]  * box[2]
                    if area>biggest:
                        biggest=area
                        bbox=box 
                bbox[0]= 0 if bbox[0]<0 else bbox[0]
                bbox[1]= 0 if bbox[1]<0 else bbox[1]
                img=img[bbox[1]: bbox[1]+bbox[3],bbox[0]: bbox[0]+ bbox[2]] 
                cv2.imwrite(dest_path+"{}.jpg".format(i), img)
            else:
                for i, faces in enumerate(data): # iterate through all the faces found
                    box=faces['box']
                    if box !=[]:
                        # return all faces found in the image
                        box[0]= 0 if box[0]<0 else box[0]
                        box[1]= 0 if box[1]<0 else box[1]
                        cropped_img=img[box[1]: box[1]+box[3],box[0]: box[0]+ box[2]]
                        captured_emotions = emo_detector.detect_emotions(cropped_img)
                        if captured_emotions != []:
                            emo_dict = captured_emotions[0]["emotions"]
                            emotion = max(emo_dict, key=emo_dict.get) 
                            if emotion in positive_emotions:
                                attentive_count += 1
    except ValueError:
        errors.append(filename)
        return filename, [], 0
    
    return attentive_count/length


def get_attention(data):   
    data = json.loads(data) 
    image = bytes(data["image"])
    logging.info('Counting students...')
    logging.info('Writing image to file...')
    im = Image.open(BytesIO(image))
    filename = 'test.jpg'
    im.save(filename)
    logging.info('Image written to file.')
    logging.info('Predicting...')
    pred = detect_emo(filename)
    return str(pred)